const counters = {
  jerimum: 0,
  farinha: 0,
  banana: 0,
  açaí: 0,
  queijo: 0,
  ovo : 0,
  cheiro: 0,
  abacate: 0,
  pumpunha: 0,
  tucuma: 0,
  melancia: 0,
  cenoura: 0,
  alface: 0,
  batata: 0,
  melao: 0,
  mel: 0,
};

function increase(item) {
  counters[item]++;
  document.getElementById(item).textContent = counters[item];
}

function decrease(item) {
  if (counters[item] > 0) {
    counters[item]--;
    document.getElementById(item).textContent = counters[item];
  }
}

document.getElementById('menu').addEventListener('click', () => {
  const sidebar = document.getElementById('sidebar');
  sidebar.style.display = sidebar.style.display === 'block' ? 'none' : 'block';
});

document.getElementById('logout').addEventListener('click', () => {
  alert('Saindo...');
});